from __future__ import print_function

x = input("Enter a number: ")
for i in range(1, 11, 1):
    print(x, "x", i, "=", (x * i))
