# To Find The Total Number Of Digits In A Number

N = int(input("Enter The number")) # To remove zeros before the number
count = len(str(N))

print(count)        
