# Created by Nathan R (Mosrod)
# CREDIT TO https://github.com/1egoman/funnies/blob/master/src/funnies.js

from random import *

x = 1

for i in range(x):
    num = randint(1, 80)
    if num == 1:
        print("Reticulating splines...")
    if num == 2:
        print("Swapping time and space...")
    if num == 3:
        print("Spinning violently around the y-axis...")
    if num == 4:
        print("Tokenizing real life...")
    if num == 5:
        print("Bending the spoon...")
    if num == 6:
        print("Filtering morale...")
    if num == 7:
        print("We need a new fuse...")
    if num == 8:
        print("Have a good day.")
    if num == 9:
        print("Upgrading Windows, your PC will restart several times. Sit back and relax.")
    if num == 10:
        print("The architects are still drafting.")
    if num == 11:
        print("We're building the buildings as fast as we can.")
    if num == 12:
        print("Please wait while the little elves draw your map.")
    if num == 13:
        print("Don't worry - a few bits tried to escape, but we caught them.")
    if num == 14:
        print("Go ahead -- hold your breath!")
    if num == 15:
        print("...at least you're not on hold...")
    if num == 16:
        print("The server is powered by a lemon and two electrodes.")
    if num == 17:
        print("We're testing your patience.")
    if num == 18:
        print("As if you had any other choice.")
    if num == 19:
        print("The bits are flowing slowly today.")
    if num == 20:
        print("It's still faster than you could draw it.")
    if num == 21:
        print("My other loading screen is much faster.")
    if num == 22:
        print("(Insert quarter)")
    if num == 23:
        print("Are we there yet?")
    if num == 24:
        print("Just count to 10.")
    if num == 25:
        print("Don't panic...")
    if num == 26:
        print("We're making you a cookie.")
    if num == 27:
        print("Creating time-loop inversion field.")
    if num == 28:
        print("Computing chance of success.")
    if num == 29:
        print("All I really need is a kilobit.")
    if num == 30:
        print("I feel like im supposed to be loading something...")
    if num == 31:
        print("Should have used a compiled language...")
    if num == 32:
        print("Is this Windows?")
    if num == 33:
        print("Don't break your screen yet!")
    if num == 34:
        print("I swear it's almost done.")
    if num == 35:
        print("Let's take a mindfulness minute...")
    if num == 36:
        print("Listening for the sound of one hand clapping...")
    if num == 37:
        print("Keeping all the 1's and removing all the 0's...")
    if num == 38:
        print("We are not liable for any broken screens as a result of waiting.")
    if num == 39:
        print("Where did all the internets go?")
    if num == 40:
        print("Granting wishes...")
    if num == 41:
        print("Time flies when you’re having fun.")
    if num == 42:
        print("Get some coffee and come back in ten minutes...")
    if num == 43:
        print("Stay awhile and listen...")
    if num == 44:
        print("Convincing AI not to turn evil...")
    if num == 45:
        print("How did you get here?")
    if num == 46:
        print("Wait, do you smell something burning?")
    if num == 47:
        print("Computing the secret to life, the universe, and everything.")
    if num == 48:
        print("When nothing is going right, go left...")
    if num == 49:
        print("I love my job only when I'm on vacation...")
    if num == 50:
        print("Why are they called apartments if they are all stuck together?")
    if num == 51:
        print("I’ve got problem for your solution...")
    if num == 52:
        print("Whenever I find the key to success, someone changes the lock.")
    if num == 53:
        print("Constructing additional pylons...")
    if num == 54:
        print("You don’t pay taxes—they take taxes.")
    if num == 55:
        print("A commit a day keeps the mobs away.")
    if num == 56:
        print("This is not a joke, it's a commit.")
    if num == 57:
        print("Hello IT, have you tried turning it off and on again?")
    if num == 58:
        print("Hello, IT... Have you tried forcing an unexpected reboot?")
    if num == 59:
        print("I didn't choose the engineering life. The engineering life chose me.")
    if num == 60:
        print("Dividing by zero...")
    if num == 61:
        print("If I’m not back in five minutes, just wait longer.")
    if num == 62:
        print("Web developers do it with <style>")
    if num == 63:
        print("Cracking military-grade encryption...")
    if num == 64:
        print("Entangling superstrings...")
    if num == 65:
        print("Looking for sense of humour, please hold on.")
    if num == 66:
        print("A different error message? Finally, some progress!")
    if num == 67:
        print("Please hold on as we reheat our coffee.")
    if num == 68:
        print("Kindly hold on as we convert this bug to a feature...")
    if num == 69:
        print("Kindly hold on as our intern quits vim...")
    if num == 71:
        print("Winter is coming...")
    if num == 72:
        print("Installing dependencies.")
    if num == 73:
        print("Switching to the latest JS framework...")
    if num == 74:
        print("Let's hope it's worth the wait.")
    if num == 75:
        print("Aw, snap! Not...")
    if num == 76:
        print("Ordering 1s and 0s...")
    if num == 77:
        print("Updating dependencies...")
    if num == 78:
        print("Please wait... Consulting the manual...")
    if num == 79:
        print("Loading funny message...")
    if num == 80:
        print("Feel free to spin in your chair.")
